#!/bin/bash
sudo shutdown -h now
